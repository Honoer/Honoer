<?php
return array (
  'DB_TYPE' => 'mysql',
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'h.me',
  'DB_USER' => 'root',
  'DB_PWD' => '',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'tp_',
  'OUTPUT_ENCODE' => false,
  'APP_FILE_CASE' => true,
  'APP_GROUP_LIST' => 'Home,Admin',
  'DEFAULT_GROUP' => 'Home',
  'DEFAULT_THEME' => 'Default',
  'DEFAULT_MODULE' => 'Article',
  'LAYOUT_ON' => true,
  'VAR_PAGE' => 'p',
  'TMPL_FILE_DEPR' => '-',
  'URL_MODEL' => '2',
  'WEB_NAME' => '『Honoer.com』Web技术',
  'WEB_LOGO' => '111112323',
  'WEB_RECODE' => '®copyright ©2012 All Rights Reserved.',
  'WEB_ICP' => '粤ICP备12345678号-2',
  'WEB_STATISTIC' => '<script type="text/javascript">
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "//hm.baidu.com/hm.js?45b34fa03392243e4038fd601390f9dc";
            var s = document.getElementsByTagName("script")[0]; 
            s.parentNode.insertBefore(hm, s);
        })();
    </script>',
  'submit' => '',
  '__hash__' => '26af7f0bb752e74cc6496783c779eaef_7df000ed77482ff1b124a20900f94d50',
);
?>