<?php

//Admin项目配置文件
return array(
    'PAGESIZE' => 20,
);
?>
