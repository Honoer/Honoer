<?php

class AboutAction extends CommonAction {

    public function index() {
        $this->display('Index:index');
    }

}