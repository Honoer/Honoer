<?php

//数据库配置文件
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
//    'DB_NAME' => 'h.me',
//    'DB_USER' => 'root',
//    'DB_PWD' => '',
    'DB_NAME' => 'mfzemgrh3e_bolg',
    'DB_USER' => 'mfzemgrh3e_root',
    'DB_PWD' => 'D1dLWGXh',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'tp_',
);
?>
