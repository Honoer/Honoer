<?php

class Arr extends ArrayObject
{
	static function make($source = null)
	{
		if (is_null($source))			return new self;
		if (is_array($source))			return new self($source);
		if (is_a($source, __CLASS__))	return new self($source);
		return new self(func_get_args());
	}

	function to_a()							{ return (array)$this; }

	function keys()							{ return new self(array_keys((array)$this)); }
	function values()						{ return new self(array_values((array)$this)); }

	function get($key, $default = null)		{ return array_key_exists($key, (array)$this) ? $this[$key] : $default; }
	function has($value)					{ return in_array($value, (array)$this); }
	function get_key($value)				{ return array_search($value, (array)$this); }
	function has_key($key)					{ return array_key_exists($key, (array)$this); }
	function has_key_value($key, $value)	{ return array_key_exists($key, (array)$this) && $this[$key] == $value; }

	function slice($offset, $length = null, $preserve_keys = false)
	{
		return new self(array_slice((array)$this, $offset, $length, $preserve_keys));
	}

	/**
	 * Wrapper for array_merge($this, $array)
	 * @param self $array
	 * @return self
	 */
	function merge(self $array = null)
	{
		return new self(array_merge((array)$this, (array)$array));
	}

	/**
	 * Wrapper for array_merge($array, $this) - reversed arguments
	 * @param self $array
	 * @return self
	 */
	function merge_into(self $array = null)
	{
		return new self(array_merge((array)$array, (array)$this));
	}

	function implode($glue)
	{
		return implode($glue, (array)$this);
	}

	function flatten()
	{
		$res = self::make();
		foreach ($this as $elem)
			if (is_array($elem))			$res   = $res->merge(self::make($elem)->flatten());
			elseif (is_a($elem, __CLASS__))	$res   = $res->merge($elem->flatten());
			else							$res[] = $elem;
		return $res;
	}

	function walk($func)			{					foreach ($this as $k => &$v)	$func($v);							return $this; }
	function map($func)				{ $r = new self();	foreach ($this as $k => $v)		$r[$k] = $func($v);					return $r; }
	function filter($func)			{ $r = new self();	foreach ($this as $k => $v)		if ($func($v)) $r[$k] = $v;			return $r; }
	function reduce($init, $func)	{ $r = $init;		foreach ($this as $k => $v)		$r = $func($v, $r);					return $r; }

	function first($func)			{					foreach ($this as $k => $v)		if ($func($v)) return $v;			return null; }
	function first_key($func)		{					foreach ($this as $k => $v)		if ($func($v)) return $k;			return null; }
	function for_any($func)			{					foreach ($this as $k => $v)		if ($func($v)) return true;			return false; }
	function for_all($func)			{					foreach ($this as $k => $v)		if (!$func($v)) return false;		return true; }

	function walk_k($func)			{					foreach ($this as $k => &$v)	$func($k, $v);						return $this; }
	function map_k($func)			{ $r = new self();	foreach ($this as $k => $v)		$r[$k] = $func($k, $v);				return $r; }
	function filter_k($func)		{ $r = new self();	foreach ($this as $k => $v)		if ($func($k, $v)) $r[$k] = $v;		return $r; }
	function reduce_k($init, $func)	{ $r = $init;		foreach ($this as $k => $v)		$r = $func($k, $v, $r);				return $r; }

	function first_k($func)			{					foreach ($this as $k => $v)		if ($func($k, $v)) return $v;		return null; }
	function first_key_k($func)		{					foreach ($this as $k => $v)		if ($func($k, $v)) return $k;		return null; }
	function for_any_k($func)		{					foreach ($this as $k => $v)		if ($func($k, $v)) return true;		return false; }
	function for_all_k($func)		{					foreach ($this as $k => $v)		if (!$func($k, $v)) return false;	return true; }
}
