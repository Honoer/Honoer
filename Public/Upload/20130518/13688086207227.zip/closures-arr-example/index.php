<?
include "arr.php";

$a1 = Arr::make(array(1 => 10, 2 => 20, 3 => 30, 4 => 40));
var_dump("Base", (array)$a1);

// simple filtering
$a2 = $a1->filter(function ($v) { return $v > 15; });
var_dump("Filtered values > 15", (array)$a2);

// value and key filtering
$a3 = $a1->filter_k(function ($k, $v) { return $v > 15 && $k < 4; });
var_dump("Filtered values > 15 and keys < 4", (array)$a3);

// sum of squares where values <= 20
$a4 = $a1
	->filter(function ($v) { return $v <= 20; })
	->map(function ($v) { return $v * $v; })
	->reduce(0, function ($v, $acc) { return $v + $acc; })
;
var_dump("Reduced sum of squares where values <= 20", (array)$a4);

// other utility
$all_even = $a1->for_all(function ($v) { return $v % 2 == 0; });
$any_odd = $a1->for_any(function ($v) { return $v % 2 == 1; });
var_dump("Are all elements even?", $all_even);
var_dump("Is at least one element odd?", $any_odd);

// in-place modification
$a1->walk(function (&$v) { $v += 1; });
var_dump("Base after walk", (array)$a1);